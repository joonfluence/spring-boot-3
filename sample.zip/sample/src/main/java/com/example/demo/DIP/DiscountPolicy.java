package com.example.demo.DIP;

public interface DiscountPolicy {
    int discount(int price);
}
